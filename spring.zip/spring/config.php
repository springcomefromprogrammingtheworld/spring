<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
header("Content-type: text/html; charset=utf-8");