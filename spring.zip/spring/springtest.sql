/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : springtest

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-10-30 14:37:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `s_admin`
-- ----------------------------
DROP TABLE IF EXISTS `s_admin`;
CREATE TABLE `s_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `username` varchar(40) NOT NULL COMMENT '管理员登录名',
  `password` varchar(32) NOT NULL COMMENT '管理员登陆密码',
  `user_email` varchar(50) NOT NULL COMMENT '管理员邮箱',
  `login_count` mediumint(8) DEFAULT NULL COMMENT '登陆次数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '账户状态，禁用为0   启用为1',
  `login_ip` int(32) NOT NULL COMMENT '最后登陆ip地址',
  `login_time` int(32) DEFAULT NULL COMMENT '最后登陆时间',
  `head` varchar(255) DEFAULT NULL COMMENT '管理员头像',
  `create_time` int(11) DEFAULT NULL COMMENT '管理员创建时间',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示在管理员列表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_admin
-- ----------------------------
INSERT INTO `s_admin` VALUES ('1', 'spring', 'e10adc3949ba59abbe56e057f20f883e', '', '68', '1', '2130706433', '1509345153', './ueditor/upload/2017-10-25/59f08a96ce22e.jpg', '1444546437', '1');
INSERT INTO `s_admin` VALUES ('2', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '', '17', '1', '2130706433', '1508936985', './ueditor/upload/2017-10-25/59f08a96ce22e.jpg', '1444546437', '1');

-- ----------------------------
-- Table structure for `s_article`
-- ----------------------------
DROP TABLE IF EXISTS `s_article`;
CREATE TABLE `s_article` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `title` varchar(60) NOT NULL COMMENT '文章标题',
  `description` varchar(255) NOT NULL COMMENT '文章描述',
  `pic` varchar(100) NOT NULL COMMENT '文章缩略图',
  `content` mediumtext NOT NULL COMMENT '文章内容',
  `cate_id` mediumint(9) NOT NULL,
  `time` int(10) NOT NULL COMMENT '发布时间',
  `author` varchar(25) NOT NULL COMMENT '作者',
  `key` varchar(255) NOT NULL COMMENT '关键词',
  `is_show` int(1) NOT NULL DEFAULT '1' COMMENT '是否显示文章 1显示 0不显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_article
-- ----------------------------

-- ----------------------------
-- Table structure for `s_article_category`
-- ----------------------------
DROP TABLE IF EXISTS `s_article_category`;
CREATE TABLE `s_article_category` (
  `cate_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章分类id',
  `cate_name` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分类名称',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` tinyint(2) NOT NULL COMMENT '排序',
  `pid` tinyint(4) NOT NULL COMMENT '父级栏目id',
  PRIMARY KEY (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_article_category
-- ----------------------------
INSERT INTO `s_article_category` VALUES ('28', 'PHP', 'php', '学习PHP,记录PHP。', '4', '0');
INSERT INTO `s_article_category` VALUES ('29', '一点点个人感悟', '感悟', '一些个人感悟。', '1', '0');
INSERT INTO `s_article_category` VALUES ('32', '程序与算法', '程序,算法', '程序与算法', '3', '0');
INSERT INTO `s_article_category` VALUES ('33', '去过的地方', '去哪儿', '记录自己去过哪里，走到哪里。', '2', '0');
INSERT INTO `s_article_category` VALUES ('34', '散文诗歌', '散文诗歌', '主要写些散文诗歌。', '0', '0');
INSERT INTO `s_article_category` VALUES ('35', '生活', '生活', '生活也许充满无限可能!', '0', '0');

-- ----------------------------
-- Table structure for `s_auth_group`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_group`;
CREATE TABLE `s_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` varchar(1000) NOT NULL DEFAULT '',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_group
-- ----------------------------
INSERT INTO `s_auth_group` VALUES ('1', '超级管理员', '1', '1,2,44,45,3,4,47,46,5,6,52,53,59,31,8,9,10,25,26,58,11,12,13,14,15,16,23,24,17,18,19,21,22,57,48', '1444546437');
INSERT INTO `s_auth_group` VALUES ('3', '文章管理员', '1', '1,2,3,4,5', '1444546437');

-- ----------------------------
-- Table structure for `s_auth_group_access`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_group_access`;
CREATE TABLE `s_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_group_access
-- ----------------------------
INSERT INTO `s_auth_group_access` VALUES ('1', '1');
INSERT INTO `s_auth_group_access` VALUES ('2', '3');
INSERT INTO `s_auth_group_access` VALUES ('21', '3');

-- ----------------------------
-- Table structure for `s_auth_rule`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_rule`;
CREATE TABLE `s_auth_rule` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `title` varchar(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` smallint(5) NOT NULL COMMENT '父级id',
  `sort` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(30) DEFAULT NULL COMMENT '备注',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显现在左边菜单 1显示 0不显示',
  `level` tinyint(4) NOT NULL COMMENT '权限等级',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_rule
-- ----------------------------
INSERT INTO `s_auth_rule` VALUES ('1', 'Admin/test', '权限管理', '1', '1', '', '0', '1', '1444546437', '1507592000', '不存在此操作主要是为了绕过TP3.2.3authl类权限验证', '1', '1');
INSERT INTO `s_auth_rule` VALUES ('2', 'Admin/admin_lst', '管理员列表', '1', '1', '', '1', '2', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('3', 'Admin/admin_add', '添加管理员', '1', '1', '', '1', '3', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('4', 'Admin/auth_group', '用户组', '1', '1', '', '1', '4', '1444546437', '1507592000', '用户组', '1', '2');
INSERT INTO `s_auth_rule` VALUES ('5', 'Admin/group_add', '添加用户组', '1', '1', '', '1', '5', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('6', 'Admin/auth_rule', '权限及菜单', '1', '1', '', '1', '6', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('8', 'Article/test', '文章管理', '1', '1', '', '0', '8', '1444546437', '1507592000', '不存在此操作主要是为了绕过TP3.2.3authl类权限验证', '1', '1');
INSERT INTO `s_auth_rule` VALUES ('9', 'Article/lst', '文章列表', '1', '1', '', '8', '9', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('10', 'Article/cate_lst', '分类列表', '1', '1', '', '8', '10', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('11', 'Article/add', '添加分类', '1', '1', '', '8', '11', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('12', 'Article/publish', '发布文章', '1', '1', '', '8', '12', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('13', 'Visit/test', '访客列表', '1', '1', '', '0', '13', '1444546437', '1508465299', '不存在此操作主要是为了绕过TP3.2.3authl类权限验证', '1', '1');
INSERT INTO `s_auth_rule` VALUES ('14', 'Visit/lst', '访客列表', '1', '1', '', '13', '14', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('15', 'Tag/test', '标签管理', '1', '1', '', '0', '14', '1444546437', '1507592000', '不存在此操作主要是为了绕过TP3.2.3authl类权限验证', '1', '1');
INSERT INTO `s_auth_rule` VALUES ('16', 'Tag/lst', '标签列表', '1', '1', '', '15', '15', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('17', 'Tag/add', '添加标签', '1', '1', '', '15', '16', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('18', 'Link/test', '链接管理', '1', '1', '', '0', '20', '1444546437', '1507592000', '不存在此操作主要是为了绕过TP3.2.3authl类权限验证', '1', '1');
INSERT INTO `s_auth_rule` VALUES ('19', 'Link/lst', '友链列表', '1', '1', '', '18', '21', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('21', 'Link/edit', '修改友链', '1', '1', '', '19', '23', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('22', 'Link/del', '删除友链', '1', '1', '', '19', '22', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('23', 'Tag/edit', '修改标签', '1', '1', '', '16', '18', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('24', 'Tag/del', '删除标签', '1', '1', '', '16', '18', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('25', 'Article/edit', '修改', '1', '1', '', '10', '10', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('26', 'Article/del', '删除', '1', '1', '', '10', '10', '1444546437', '1507592000', null, '1', '3');
INSERT INTO `s_auth_rule` VALUES ('47', 'Admin/group_del', '删除', '1', '1', '', '4', '0', '1508591683', null, '删除用户组', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('31', 'Admin/add_rule', '添加权限菜单', '1', '1', '', '1', '7', '1444546437', '1507592000', null, '1', '2');
INSERT INTO `s_auth_rule` VALUES ('44', 'Admin/admin_edit', '编辑', '1', '1', '', '2', '0', '1508589677', null, '编辑管理员或者对管理员进行授权', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('45', 'Admin/admin_del', '删除', '1', '1', '', '2', '0', '1508589868', null, '删除非超级管理员', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('46', 'Admin/group_edit', '授权/编辑', '1', '1', '', '4', '0', '1508591568', null, '对角色/用户组进行授权编辑', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('48', 'Link/add', '添加友链', '1', '1', '', '18', '0', '1508593655', null, '添加友情链接', '1', '2');
INSERT INTO `s_auth_rule` VALUES ('52', 'Admin/auth_rule_edit', '编辑', '1', '1', '', '6', '6', '1508597678', null, '编辑权限组', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('53', 'Admin/add_sub_rule', '添加子权限', '1', '1', '', '6', '0', '1508597817', null, '添加子权限', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('57', 'Link/sort', '排序', '1', '1', '', '19', '0', '1508613177', null, '友情链接排序', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('58', 'Article/sort', '排序', '1', '1', '', '10', '0', '1508613401', null, '文章分类排序', '1', '3');
INSERT INTO `s_auth_rule` VALUES ('59', 'Admin/sort', '排序', '1', '1', '', '6', '0', '1508613554', null, '权限及菜单的排序', '1', '3');

-- ----------------------------
-- Table structure for `s_links`
-- ----------------------------
DROP TABLE IF EXISTS `s_links`;
CREATE TABLE `s_links` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `link_url` varchar(255) NOT NULL COMMENT '链接地址',
  `link_name` varchar(32) NOT NULL COMMENT '链接名称',
  `link_target` char(10) DEFAULT NULL COMMENT '链接打开方式',
  `link_description` varchar(255) DEFAULT NULL COMMENT '链接描述',
  `link_visible` tinyint(1) NOT NULL DEFAULT '1' COMMENT '链接可见性 1可见 0隐藏',
  `sort` tinyint(4) NOT NULL DEFAULT '0' COMMENT '链接排序',
  `link_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除友链 1删除 0不删除',
  PRIMARY KEY (`link_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_links
-- ----------------------------
INSERT INTO `s_links` VALUES ('4', 'http://59.110.169.166', 'SPRING极简梦空间', null, null, '1', '1', '0');

-- ----------------------------
-- Table structure for `s_tag`
-- ----------------------------
DROP TABLE IF EXISTS `s_tag`;
CREATE TABLE `s_tag` (
  `tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '标签主键',
  `tag_name` varchar(10) NOT NULL DEFAULT '' COMMENT '标签名',
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_tag
-- ----------------------------
INSERT INTO `s_tag` VALUES ('16', '夜猫');
INSERT INTO `s_tag` VALUES ('17', '码农');
INSERT INTO `s_tag` VALUES ('18', '宵夜');
