$(function(){
	$layui_body_width=$('.layui-body').width();//获取内容主体区域宽度
	$layui_header_height=$('.layui-header').height();//获取头部高度
	$layui_footer_height=$('.layui-footer').height();//获取底部高度
	$height = $(window).height()-($layui_header_height+$layui_footer_height)-10; //浏览器当前窗口可视区域高度
	$('#iframe').css('height',$height);//设置框架高度
	$('#iframe').css('width',$layui_body_width);//设置框架宽度
	//监听窗口大小改变事件
	$(window).resize(function(){
		$layui_body_width=$('.layui-body').width();//获取内容主体区域宽度
		$layui_header_height=$('.layui-header').height();//获取头部高度
		$layui_footer_height=$('.layui-footer').height();//获取底部高度
		$height = $(window).height()-($layui_header_height+$layui_footer_height); //浏览器当前窗口可视区域高度
		$('#iframe').css('height',$height);//设置框架高度
		$('#iframe').css('width',$layui_body_width);//设置框架宽度
	});


})



