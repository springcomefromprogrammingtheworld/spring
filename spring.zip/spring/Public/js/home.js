$(".backtop").hide();
$(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
        $(".backtop").fadeIn();
    } else {
        $(".backtop").fadeOut();
    }
});
$(".backtop a").click(function () {
    $("body,html").animate({
            scrollTop: 0
        },
        800);
    return false;
});

//右边栏滑动
$(".side-click").click(function () {
    if ($("#secondary").hasClass('secondary')) {
        $("#secondary").animate({right: '-330px'});
        $("#secondary").removeClass('secondary');
        $("#side-click").text("N");
    } else {
        $("#secondary").animate({right: '0px'});
        $("#secondary").addClass('secondary');
        $("#side-click").text("Y");
    }
});