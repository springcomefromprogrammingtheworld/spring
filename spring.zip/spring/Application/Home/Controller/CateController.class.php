<?php
namespace Home\Controller;
use Think\Controller;
class CateController extends CommonController {
    public function index(){
        $cate_id=I('cate_id');
        $article= D('article'); // 实例化User对象
        $count=$article->where(array('cate_id'=>$cate_id))->count();// 查询满足要求的总记录数
        $Page= new \Think\Page($count,5);//
        $Page->lastSuffix = false;
        $Page->setConfig('theme', '%FIRST% %UP_PAGE% %DOWN_PAGE% %END% ');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '尾页');
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $show       = $Page->show();//
        $list = $article->where(array('cate_id'=>$cate_id))->order('time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('page',$show);// 赋值分页输出
        $this->assign('list',$list);// 赋值数据集
        $this->cate_info();//分类信息
        $this->display();
    }

    //文章分类信息
    public function cate_info(){
        $cate_id=I('cate_id');
        $cates=D('ArticleCategory')->where(array('cate_id'=>$cate_id))->select();
        $this->assign('cates',$cates);
    }




}