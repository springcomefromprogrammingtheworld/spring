<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends CommonController {

    //引导页
    public function index(){
           $this->display();
    }

    //主页内容
    public function main(){
        $article= D('article');
        $count=$article->count();
        $Page= new \Think\Page($count,5);
        $Page->lastSuffix = false;
        $Page->setConfig('theme', '%FIRST% %UP_PAGE% %DOWN_PAGE% %END% ');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '尾页');
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $show = $Page->show();
        $list = $article->order('time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('page',$show);
        $this->assign('list',$list);
        $this->display();
    }

    //关于我
    public function about(){
        $this->display();
    }

    //主页html模板
    public function maincopy(){
        $this->display();
    }
}