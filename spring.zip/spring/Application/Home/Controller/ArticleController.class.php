<?php
namespace Home\Controller;
use Think\Controller;
class ArticleController extends CommonController {
    public function index(){
        $arts=D('article')->find(I('id'));
        $arts['content']=htmlspecialchars_decode($arts['content']);//html处理
        $this->assign('arts',$arts);
        $this->catename($arts['cate_id']);
        $this->other(I('id'));
        $this->display();
    }

    public function catename($cate_id){
        $cates=D('ArticleCategory')->find($cate_id);
        $this->assign('cate_name',$cates['cate_name']);
    }


    public function other($id){
        $article=D('article');
        $articles=$article->find($id);
        $cate_id=$articles['cate_id'];
        $prevs=$article->where('id<'.$id)->where(array('cate_id'=>$cate_id))->order('id desc')->find();
        $nexts=$article->where('id>'.$id)->where(array('cate_id'=>$cate_id))->order('id asc')->find();
        $this->assign('prevs',$prevs);
        $this->assign('nexts',$nexts);
    }
}