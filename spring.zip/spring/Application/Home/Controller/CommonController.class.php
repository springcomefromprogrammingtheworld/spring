<?php
namespace Home\Controller;
use Think\Controller;
//前台公共数据控制器
class CommonController extends Controller {
    public function __construct(){
        parent::__construct();
        $this->nav();
        $this->link();
        $this->news();
    }

    //分类列表
    public function nav(){
        $cate=D('ArticleCategory');
        $cateres=$cate->order('sort desc')->select();
        $this->assign('cateres',$cateres);
    }


    //友情链接
    public function link(){
        $link=D('links');
        $linkres=$link->order('sort desc')->select();
        $this->assign('linkres',$linkres);
    }


    //最新文章
    public function news(){
        $artres=D('article')->order('time desc')->limit(4)->select();
        $this->assign('artres',$artres);
    }

}