<?php
return array(
	//'配置项'=>'配置值'
    'DEFAULT_CONTROLLER'  => 'Index',       //后台默认访问的控制器
    'DEFAULT_ACTION'  	  => 'index',        //后台默认访问的方法
);