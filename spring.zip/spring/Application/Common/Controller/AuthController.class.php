<?php
/*
 * @thinkphp3.2.3  auth认证   php5.3以上
 * @Created on 2017/10/22
 * @Author  spring   4666232689@qq.com
 */
namespace Common\Controller;
use Think\Controller;
use Think\Auth;
use Think\Model;
//权限认证
class AuthController extends Controller
{
    protected function _initialize()
    {
        //session不存在时，不允许直接访问
        if (session('aid')) {
            $admin = M("admin");
            $adminname = session('username');
            $map['id'] = session('aid');
            $admin_head = $admin->where($map)->field('head')->select();
            $this->assign("admin_head", $admin_head);
            $this->assign('adminname', $adminname);
        } else {
            $this->error('还未登陆!', U('Login/login'));
        }
        //session存在时，不需要验证的权限
        $not_check = array('Index/index', 'Index/main',
            'Index/clear_cache', 'Index/edit_pwd', 'Login/logout','Index/sys');
        //当前操作的请求                 模块名/方法名
        if (in_array(CONTROLLER_NAME . '/' . ACTION_NAME, $not_check)) {
            return true;
        }

        //超级管理员时不用验证权限
        if(session('aid')==1){
            return true;
        }

        //下面代码动态判断权限
        $auth = new Auth();
        //权限验证有效代码 start
        if($auth->check( CONTROLLER_NAME . '/' . ACTION_NAME, session('aid'))){
            return true;
        }else{
            //没有权限执行逻辑
            $this->success('没有权限',U('Login/no_control'),1);
            exit;
        }
        //权限验证有效代码 end
    }
}