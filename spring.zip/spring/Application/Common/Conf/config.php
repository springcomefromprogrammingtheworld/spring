<?php
return array(
	//'配置项'=>'配置值'
    //'配置项'=>'配置值'
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  '127.0.0.1', // 服务器地址
    'DB_NAME'               =>  'springtest',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  '',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  's_',    // 数据库表前缀
	'URL_MODEL'             =>  2,
    'DB_CHARSET'=> 'utf8', // 字符集
    'TMPL_PARSE_STRING' => array(
        '__PUBLIC__' => __ROOT__ . '/Public',
        '__ADMIN__' => SITE_URL,
        '__JS__' => __ROOT__ . '/Public/js',
        '__LAYUI__' => __ROOT__ . '/Public/layui',
        '__CSS__' => __ROOT__ . '/Public/spring',
        '__IMAGE__' => __ROOT__ . '/Public/upload',
    ),
);