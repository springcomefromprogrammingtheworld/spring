<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,user-scalable=no">
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/global.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/home.css"/>
    <title>SPRING极简梦空间</title>
</head>
<body>
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!--响应式容器 s-->
<div class="layui-container">
    <!--header s-->
    <!--header s-->
<div class="layui-row" id="header">
	<div class="layui-col-xs12">
		<a id="logo" href="/spring/Home/Index/main/">SPRING极简梦空间</a>
		<p class="description">从哪里来，到哪里去?</p>
	</div>
</div>

<!--header e-->
<!--nav s-->
<nav id="nav-menu" class="clearfix layui-row">
	<div class="layui-col-xs12" style="text-align: center">
		<a class="<?php if($_GET[type] == 2): ?>this<?php else: echo ((isset($_GET[type]) && ($_GET[type] !== ""))?($_GET[type]):'this'); endif; ?>" href="/spring/Home/Index/main/type/2">博客</a>
		<a class="<?php if($_GET[type] == 1): ?>this<?php else: endif; ?>" href="/spring/Home/Index/about/type/1" title="关于">关于</a>
		<div style="clear: both"></div>
	</div>
</nav>
<!--nav e-->
    <!--header e-->


    <!--文章列表摘要 s-->
    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><article class="layui-row">
            <div class="layui-col-xs12">
                <date class="post-meta">发布时间:<?php echo (date("y-m-d",$vo["time"])); ?></date>
                <header>
                    <h2 class="post-title"><a href="/spring/Home/Article/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a></h2>
                    <div class="pic">
                        <img src="/spring/<?php echo ($vo["pic"]); ?>" alt="<?php echo ($vo["title"]); ?>">
                        <p class="auto-linefeed suo-jin">
                            <?php echo ($vo["description"]); ?>
                        </p>
                        <div style="clear: both"></div>
                    </div>
                    <div class="post-content">
                        <p class="more"><a href="/spring/Home/Article/index/id/<?php echo ($vo["id"]); ?>">- 阅读全文 -</a></p>
                    </div>
                </header>
            </div>
        </article><?php endforeach; endif; else: echo "" ;endif; ?>
    <!--文章列表摘要 e-->


    <!--文章分页 s-->
    <div class="layui-row" style="margin-top: 20px;">
        <div class="layui-col-xs12 page">
            <?php echo ($page); ?>
        </div>
    </div>
    <!--文章分页 e-->



</div>
<!--响应式容器 e-->
<!--底部 s-->

<!--返回顶部 s-->
<p class="backtop" style="display: block;"><a href="#">↑</a></p>
<!--返回顶部 e-->
<!--底部 s-->
<footer id="footer">
	<div class="container">
		©2017-<a rel="nofollow" href="/spring/Home/Index/main/">SPRING极简梦空间</a>.
	</div>
</footer>
<!--底部 e-->

<!--底部 e-->

<!--右边栏 s-->
<!--右边栏开关 s-->
<div class="side-click icon-arrow-down" id="side-click">N</div>
<!--右边栏开关 e-->
<div id="secondary">
    <div class="sidebar">

        <!--<section class="widget">-->
            <!--<form id="search" method="post" action="./">-->
                <!--<input type="text" name="s" class="text" placeholder="搜索...">-->
                <!--<button type="submit" class="submit icon-search">搜索</button>-->
            <!--</form>-->
        <!--</section>-->

        <section class="widget">
            <h3 class="widget-title">分类</h3>
            <ul class="widget-list widget-list2">
                <?php if(is_array($cateres)): $i = 0; $__LIST__ = $cateres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cate): $mod = ($i % 2 );++$i;?><li><h3><a href="/spring/Home/Cate/index/cate_id/<?php echo ($cate["cate_id"]); ?>"><?php echo ($cate["cate_name"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>


        <section class="widget">
            <div class="widget-title">最新文章</div>
            <ul class="widget-list widget-list2">
                <?php if(is_array($artres)): $i = 0; $__LIST__ = $artres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$art): $mod = ($i % 2 );++$i;?><li><h3><a href="/spring/Home/Article/index/id/<?php echo ($art["id"]); ?>/title/<?php echo ($art["title"]); ?>"><?php echo ($art["title"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>


        <section class="widget">
            <div class="widget-title">友情链接</div>
            <ul class="widget-list widget-list2">
                <?php if(is_array($linkres)): $i = 0; $__LIST__ = $linkres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$link): $mod = ($i % 2 );++$i;?><li><h3><a href="<?php echo ($link["link_url"]); ?>" target="_blank"><?php echo ($link["link_name"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>

    </div>
</div>

<!--右边栏 s-->

<script src="/spring/Public/layui/layui.js"></script>
<script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
<script src="/spring/Public/js/home.js"></script>
</body>
</html>