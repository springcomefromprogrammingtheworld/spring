<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en"
      style="background-image:url('/spring/ueditor/upload/2017-10-25/lunhui.jpg'); background-repeat:no-repeat;background-attachment:fixed;background-position:top;height:100%;width:100%;overflow: hidden;background-size:cover;">
<head>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
    <script src="/spring/Public/js/base.js"></script>
    <title>SPRING极简梦空间</title>
    <style>
        html {
            background: rgba(191, 193, 42, 0.6);
        }
    </style>
</head>
<body>
<div class='springaciton flex-container' style="  width: 100%;position: relative;text-align: center;padding-top: 250px;">
    <!--旋转圆 s-->
    <div class="yuan layui-anim layui-anim-rotate layui-anim-loop rotate">
        <div>坚持</div>
    </div>
    <div class="yuan layui-anim layui-anim-rotate layui-anim-loop rotate">
        <div>超越</div>
    </div>
    <div class="yuan layui-anim layui-anim-rotate layui-anim-loop rotate">
        <div>自我</div>
    </div>
    <!--旋转圆 e-->
</div>
<!--进入按钮 s-->
<div style="width: 100%;text-align: center;position: absolute;bottom: 200px;">
    <button class="come-in button" onclick="window.location.href='/spring/Home/Index/main'">进入</button>
</div>
<!--进入按钮 e-->


<script>

</script>
</body>
</html>