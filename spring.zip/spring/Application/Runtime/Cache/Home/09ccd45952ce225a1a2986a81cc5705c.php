<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,user-scalable=no">
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/global.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/home.css"/>
    <title>SPRING极简梦空间</title>
</head>
<body>
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!--响应式容器 s-->
<div class="layui-container">
    <!--header s-->
    <!--header s-->
<div class="layui-row" id="header">
	<div class="layui-col-xs12">
		<a id="logo" href="/spring/Home/Index/about/type/1">SPRING极简梦空间</a>
		<p class="description">从哪里来，到哪里去?</p>
	</div>
</div>

<!--header e-->
<!--nav s-->
<nav id="nav-menu" class="clearfix layui-row">
	<div class="layui-col-xs12" style="text-align: center">
		<a class="<?php if($_GET[type] == 2): ?>this<?php else: echo ((isset($_GET[type]) && ($_GET[type] !== ""))?($_GET[type]):'this'); endif; ?>" href="/spring/Home/Index/main/type/2">博客</a>
		<a class="<?php if($_GET[type] == 1): ?>this<?php else: endif; ?>" href="/spring/Home/Index/about/type/1" title="关于">关于</a>
		<div style="clear: both"></div>
	</div>
</nav>
<!--nav e-->
    <!--header e-->

    <!--关于我 s-->
    <article class="layui-row">
        <div class="layui-col-xs12">
            <header>
                <h1 class="post-title"><a href="/spring/Home/Index/about/type/1">关于我</a></h1>
                <div class="post-content" style="padding-top: 60px;">
                    <p>你好，我是spring(网名),php程序员。</p>
                    <p>2016年走进了前端开发再到2017年慢慢进入后端php开发，这是个改变也是个起点。</p>
                    <p>我希望改变，我希望自己能完成一些事，一些目标或者叫个人的小目标。</p>
                    <p>比如这个个人的博客就是我的一个小目标。</p>
                    <p>找到目标然后去执行它，也许这世间有许多不可抗力的因素不管最后能不能实现，我可以对的起自己的良心说我已经尽力了。</p>
                    <p>邮箱:826671858@qq.com</p>
                </div>
                <h1 class="post-title"><a href="/spring/Home/Index/about/type/1">关于这个网站</a></h1>
                <div class="post-content" style="padding-top: 60px;">
                    <p>1.前台采用layui前端框架的响应式能力栅格系统以及css的媒体查询基本实现了pc移动端的兼容展示。</p>
                    <p>2.后台布局也是基于layui框架的模板。</p>
                    <p>3.后端技术采用了thinkphp3.2.3框架+mysql数据库,实现博客需求的基本功能以及thinkphp3.2.3Auth类的权限控制。</p>
                    <p>4.前台现阶段自己需要的功能就这些了。(能写写文章记录一下自己的生活和学习也可以了，所以叫极简梦空间，简单。)</p>
                    <p>5.总结:算是整合了一下自己的前端与后端的整体技术,应该加深下某一方面的技术深度了。</p>
                </div>
            </header>
        </div>
    </article>
    <!--关于我 e-->
</div>
<!--响应式容器 e-->
<!--底部 s-->

<!--返回顶部 s-->
<p class="backtop" style="display: block;"><a href="#">↑</a></p>
<!--返回顶部 e-->
<!--底部 s-->
<footer id="footer">
	<div class="container">
		©2017-<a rel="nofollow" href="/spring/Home/Index/main/">SPRING极简梦空间</a>.
	</div>
</footer>
<!--底部 e-->

<!--底部 e-->

<!--右边栏 s-->
<!--右边栏开关 s-->
<div class="side-click icon-arrow-down" id="side-click">N</div>
<!--右边栏开关 e-->
<div id="secondary">
    <div class="sidebar">

        <!--<section class="widget">-->
            <!--<form id="search" method="post" action="./">-->
                <!--<input type="text" name="s" class="text" placeholder="搜索...">-->
                <!--<button type="submit" class="submit icon-search">搜索</button>-->
            <!--</form>-->
        <!--</section>-->

        <section class="widget">
            <h3 class="widget-title">分类</h3>
            <ul class="widget-list widget-list2">
                <?php if(is_array($cateres)): $i = 0; $__LIST__ = $cateres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cate): $mod = ($i % 2 );++$i;?><li><h3><a href="/spring/Home/Cate/index/cate_id/<?php echo ($cate["cate_id"]); ?>"><?php echo ($cate["cate_name"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>


        <section class="widget">
            <div class="widget-title">最新文章</div>
            <ul class="widget-list widget-list2">
                <?php if(is_array($artres)): $i = 0; $__LIST__ = $artres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$art): $mod = ($i % 2 );++$i;?><li><h3><a href="/spring/Home/Article/index/id/<?php echo ($art["id"]); ?>"><?php echo ($art["title"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>


        <section class="widget">
            <div class="widget-title">友情链接</div>
            <ul class="widget-list widget-list2">
                <?php if(is_array($linkres)): $i = 0; $__LIST__ = $linkres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$link): $mod = ($i % 2 );++$i;?><li><h3><a href="<?php echo ($link["link_url"]); ?>" target="_blank"><?php echo ($link["link_name"]); ?></a></h3></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </section>

    </div>
</div>

<!--右边栏 s-->

<script src="/spring/Public/layui/layui.js"></script>
<script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
<script src="/spring/Public/js/home.js"></script>
</body>
</html>