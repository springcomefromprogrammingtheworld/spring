<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>标签列表</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "链接管理"."→"."标签列表";?>
    </div>
</div>
<div class="layui-field-box">
    <table class="layui-table" lay-size="lg">
        <thead>
        <tr>
            <th class="text-center">标签编号</th>
            <th class="text-center">标签名</th>
            <th class="text-center">操作</th>
        </tr>
        </thead>
        <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                <td class="text-center"><?php echo ($vo["tag_id"]); ?></td>
                <td class="text-center"><?php echo ($vo["tag_name"]); ?></td>
                <td class="text-center"><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Tag/edit/tag_id/<?php echo ($vo["tag_id"]); ?>/edit/修改标签">修改标签</a><a href="javascript:if(confirm('确定要删除吗?')) location='/spring/Admin/Tag/del/tag_id/<?php echo ($vo["tag_id"]); ?>'" class="layui-btn layui-btn-radius s-btn-danger">删除标签</a></td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
</div>
</body>
</html>