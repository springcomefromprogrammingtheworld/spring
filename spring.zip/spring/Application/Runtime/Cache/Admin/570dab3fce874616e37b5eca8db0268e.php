<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>添加用户组</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<style>
    /*重写框架样式 start*/
    .layui-form-checkbox {
        margin-bottom: 20px;
        margin-right: 0px !important;
    }
    /*重写框架样式 end*/
</style>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "权限管理"."→"."添加用户组";?>
    </div>
</div>
<br style="padding-top: 30px;">
<div class="layui-form-item">
    <label class="layui-form-label">全选/取消</label>
    <div class="layui-input-block">
        <input type="hidden" id="all" value="1" />
        <button class="layui-btn layui-btn-radius layui-btn-primary" lay-submit lay-filter="formDemo" style="background-color: #009688;color: white;" id="all_checkbox">全选/取消</button>
    </div>
</div>
<form class="layui-form" action="/spring/Admin/Admin/group_add" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
    <div class="layui-form-item">
        <label class="layui-form-label">角色/组</label>
        <div class="layui-input-block" style="width: 50%">
            <input type="text" name="title" required lay-verify="required" placeholder="输入角色/组" autocomplete="off"
                   class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label"></label>
        <div class="layui-input-block">
            <p style="font-size: 16px;">输入角色/组名称并分配以下你想分配的权限</p>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">分配权限</label>
        <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="layui-input-block group" style="border-bottom: solid 2px #009688;">
                <input  type="checkbox" name="rules[]" title="<?php echo ($vo["title"]); ?>" value="<?php echo ($vo["id"]); ?>"
                       id="<?php echo ($vo["id"]); ?>" class="checkbox<?php echo ($vo["id"]); ?> level_one">
                <?php if(is_array($vo['children'])): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$son): $mod = ($i % 2 );++$i;?><div class="layui-input-block">
                        <?php echo str_repeat('&nbsp;&nbsp;',$vo['level']*2); ?><input type="checkbox" name="rules[]"
                                                                                       title="<?php echo ($son["title"]); ?>"
                                                                                       value="<?php echo ($son["id"]); ?>" id="<?php echo ($son["id"]); ?>"
                                                                                       class="checkbox<?php echo ($vo["id"]); ?> level_two">
                        <?php if(is_array($son['children'])): $i = 0; $__LIST__ = $son['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$soninson): $mod = ($i % 2 );++$i;?><div class="layui-input-block">
                                <?php echo str_repeat('&nbsp;&nbsp;',$vo['level']*3); ?><input type="checkbox"
                                                                                               name="rules[]"
                                                                                               title="<?php echo ($soninson["title"]); ?>"
                                                                                               value="<?php echo ($soninson["id"]); ?>"
                                                                                               id="<?php echo ($soninson["id"]); ?>"
                                                                                               class="checkbox<?php echo ($vo["id"]); ?> level_three">
                            </div><?php endforeach; endif; else: echo "" ;endif; ?>
                    </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>

    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formDemo">保存</button>
        </div>
    </div>
    <!-- 更多表单结构排版请移步文档左侧【页面元素-表单】一项阅览 -->
</form>
</div>
<script src="/spring/Public/layui/layui.js"></script>
<script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
<script>
    layui.use('form', function () {
        var form = layui.form;
        //各种基于事件的操作，下面会有进一步介绍
        //监听提交
        $('input[type="checkbox"]').prop('checked', true);  //默认全选权限
        $(".layui-form-checkbox").addClass('layui-form-checked');//默认全选权限


        //分组选中
        $(".layui-form-checkbox").on('click', function (e) {
            var children = $(this).parent('.layui-input-block').find('.layui-form-checkbox');//找到所有复选框模拟按钮
            var input = $(this).parent('.layui-input-block').find('input');//找到所有复选框

            var moni_level_two = $(this).parent().parent('.group').children().eq(1);//找到二级单个子级复选框模拟按钮
            var level_two = $(this).parent().parent('.group').children().eq(0);//找到二级单个子级复选框

            var moni_level_three = $(this).parent().parent().parent('.group').children().eq(1);//找到三级单个子级复选框模拟按钮
            var level_three = $(this).parent().parent().parent('.group').children().eq(0);//找到三级单个子级复选框

            var moni_level_three1 = $(this).parent('.layui-input-block').parent('.layui-input-block').children().eq(1);//找到三级单个子级复选框模拟按钮
            var level_three1 = $(this).parent('.layui-input-block').parent('.layui-input-block').children().eq(0);//找到三级单个子级复选框

            if ($(this).prev('input').hasClass('level_three')) {   //如果当前选择的是三级复选框
                if ($(this).hasClass('layui-form-checked') == true) {

                    $(this).addClass('layui-form-checked');  //选中当前复选框
                    $(this).prev('input').prop('checked', true);

                    moni_level_three.addClass('layui-form-checked');    //选择三级复选框的同时把顶级父类一级复选框选中
                    level_three.prop('checked', true);

                    if (!moni_level_three1.hasClass('layui-form-checked') == true) {  //选择三级复选框的同时把直接父类二级复选框选中
                        moni_level_three1.addClass('layui-form-checked');
                        level_three1.prop('checked', true);
                    }
                } else {
                    $(this).removeClass('layui-form-checked');   //取消当前复选框
                    $(this).prev('input').prop('checked', false);
                }
            } else {
                if ($(this).hasClass('layui-form-checked') == true) {
                    if ($(this).prev('input').hasClass('level_one')) {   //如果当前选择的是顶级复选框
                        if ($(this).hasClass('layui-form-checked')) {    //如果当前顶级复选框有选中则取消下面子类所有的复选框包括自身
                            children.removeClass('layui-form-checked');
                            input.prop('checked', false);
                        }
                    } else {
                        if (!moni_level_two.hasClass('layui-form-checked') == true) { //选择二级级复选框的同时把直接父类二级复选框选中
                            moni_level_two.addClass('layui-form-checked');
                            level_two.prop('checked', true);
                        } else {
                        }
                    }
                    children.addClass('layui-form-checked');
                    input.prop('checked', true);
                } else {
                    children.removeClass('layui-form-checked');
                    input.prop('checked', false);
                }


            }


        });



        $("#all_checkbox").click(function(){
            if($('.layui-form-checkbox').hasClass('layui-form-checked')){
                $('.layui-form-checkbox').removeClass('layui-form-checked');
                //此处使用attr第二次设置的时候会除问题，解决办法使用prop函数，jquery版本必须要1.6.1以上
                $('input[type="checkbox"]').prop('checked', false);
            }else{
                $('.layui-form-checkbox').addClass('layui-form-checked');
                $('input[type="checkbox"]').prop('checked', true);
            }

        });
    });

    function checkbox(id) {
        if (box == 1) {
            $('#box' + id).attr('value', 0);
            //此处使用attr第二次设置的时候会除问题，解决办法使用prop函数，jquery版本必须要1.6.1以上
            $('.checkbox' + id).prop('checked', true);
        } else {
            $('#box' + id).attr('value', 1);
            $('.checkbox' + id).prop('checked', false);
        }
    }
</script>
</body>
</html>