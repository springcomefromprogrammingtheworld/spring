<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>清除缓存</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        清除缓存
    </div>
</div>
<div class="layui-form"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
    <div class="layui-form-item">
        <div class="layui-input-block">
            <input type="checkbox" name="clear" value="1" title="后台编译缓存">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <input type="checkbox" name="clear" value="2" title="前台编译缓存">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <input type="checkbox" name="clear" value="3" title="字段缓存">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <input type="checkbox" name="clear" value="4" title="临时文件缓存">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <a  class="layui-btn" onclick="all_checked()">全选/反选</a>
            <a class="layui-btn" onclick="clear_cache()">一键清空缓存</a>
        </div>
    </div>
</div>
<script src="/spring/Public/layui/layui.js"></script>
<script>
    layui.use('form', function(){
        var form = layui.form;
        var layer = layui.layer;
        //各种基于事件的操作，下面会有进一步介绍
        //监听提交
    });

    //全选
    function all_checked(){
        if($('.layui-form-checkbox').hasClass('layui-form-checked')){
            $('.layui-form-checkbox').removeClass('layui-form-checked');
            //此处使用attr第二次设置的时候会除问题，解决办法使用prop函数，jquery版本必须要1.6.1以上
            $('input[type="checkbox"]').prop('checked', false);
        }else{
            $('.layui-form-checkbox').addClass('layui-form-checked');
            $('input[type="checkbox"]').prop('checked', true);
        }
    }

    //获取所有checbox的值
    function get_checbbox() {
        var str = '';
        $('input[name="clear"]:checked').each(function(){
            str += $(this).val();
        });
        return str;
    }
    //清空缓存
    function clear_cache(){
        var str = get_checbbox();
        layer.confirm('你真的需要清除缓存吗？',
                {icon: 3, title:'提示',btn: ['是的','取消'],shade: 0.5},
                function(index){
                    $.get("/spring/Admin/Index/clear_cache", { "clear":str},function(data){
                        if(data == 1){
                            layer.msg('清除缓存成功', { icon: 1, time: 3000 }, function(){
                            });
                        }else{
                            layer.msg('清除缓存失败', {icon: 2, time: 3000 });
                        }
                    }, "json");
                }
        );
    }
</script>
</body>
</html>