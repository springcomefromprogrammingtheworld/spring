<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>没有权限</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
</head>
<body>
<div style="width: 100%;text-align: center;padding-top: 200px">
<div class="layui-anim  layui-anim-loop layui-anim-upbit" style="width: 500px;height: 500px;background-color: #009688;border-radius: 250px;margin: auto;color: white;font-size: 48px;position: relative">
    <div style="position: absolute;bottom: 250px;right: 150px;">没有权限</div>
</div>
</div>
</body>
</html>