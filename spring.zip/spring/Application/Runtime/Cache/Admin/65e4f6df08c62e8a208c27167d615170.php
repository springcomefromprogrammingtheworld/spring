<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>友链列表</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "链接管理"."→"."友链列表";?>
    </div>
</div>
<div class="layui-field-box">
    <form class="layui-form" action="/spring/Admin/Link/sort" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
    <table class="layui-table" lay-size="lg">
        <thead>
        <tr>
            <th class="text-center">链接编号</th>
            <th class="text-center">排序</th>
            <th class="text-center">链接名称</th>
            <th class="text-center">链接地址</th>
            <th class="text-center">是否显示</th>
            <th class="text-center">操作</th>
        </tr>
        </thead>
        <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                <td class="text-center"><?php echo ($vo["link_id"]); ?></td>
                <td class="text-center"><input class="layui-input" type="text" name="<?php echo ($vo["link_id"]); ?>" value="<?php echo ($vo["sort"]); ?>"></td>
                <td class="text-center"><?php echo ($vo["link_name"]); ?></td>
                <td class="text-center"> <a href="<?php echo ($vo["link_url"]); ?>" target="_blank"><?php echo ($vo["link_url"]); ?></a></td>
                <td class="text-center"><?php if($vo['link_visible'] == 1): ?>✔
                    <?php else: ?>
                    ✘<?php endif; ?></td>
                <td class="text-center"><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Link/edit/link_id/<?php echo ($vo["link_id"]); ?>/edit/修改友链">修改友链</a><a href="javascript:if(confirm('确定要删除吗?')) location='/spring/Admin/Link/del/link_id/<?php echo ($vo["link_id"]); ?>'" class="layui-btn layui-btn-radius s-btn-danger">删除友链</a></td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        <tr>
            <td></td>
            <td><input class="layui-btn layui-btn-radius s-btn-warm" type="submit" value="排序"></td>
        </tr>
    </table>
        </form>
</div>

<script src="/spring/Public/layui/layui.js"></script>
</body>
</html>