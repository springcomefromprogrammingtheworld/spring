<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>发布文章</title>
    <link type="text/css" rel="stylesheet" href="/springblog/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/springblog/Public/spring/spring.css"/>
    <style>
        #edui1_iframeholder{
            height: 350px;
        }
        /*覆盖文本编辑器样式 end*/
    </style>
</head>
<body style="overflow-x: hidden">
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        修改文章
    </div>
</div>
<div style="padding-top: 30px;">
    <form class="layui-form" action="/springblog/Admin/Article/article_edit" method="post" enctype="multipart/form-data"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <input type="hidden" name="id" value="<?php echo ($articles["id"]); ?>">
        <div class="layui-form-item">
            <label class="layui-form-label">所属栏目</label>
            <div class="layui-input-block"  style="width: 50%">
                <select name="cate_id" lay-verify="required">
                    <option value="">请选择分类</option>
                    <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option <?php if($vo['cate_id'] == $articles['cate_id']): ?>selected="selected"<?php endif; ?> value="<?php echo ($vo["cate_id"]); ?>"><?php echo ($vo["cate_name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">标题</label>
            <div class="layui-input-block" style="width: 50%">
                <input type="text" name="title" required lay-verify="required" placeholder="请输入标题" autocomplete="off"
                       class="layui-input" value="<?php echo ($articles["title"]); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">作者</label>
            <div class="layui-input-block"  style="width: 50%">
                <input type="text" name="author" required lay-verify="required" placeholder="作者" autocomplete="off"
                       class="layui-input" value="<?php echo ($articles["author"]); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">关键词</label>
            <div class="layui-input-block"  style="width: 50%">
                <input type="text" name="key" required lay-verify="required" placeholder="多个关键词用顿号分隔"
                       autocomplete="off" class="layui-input" value="<?php echo ($articles["key"]); ?>">
            </div>
        </div>
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">请填写描述</label>
            <div class="layui-input-block"  style="width: 50%">
                <textarea name="description" placeholder="请输入描述" class="layui-textarea"><?php echo ($articles["description"]); ?></textarea>
            </div>
        </div>
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">缩略图</label>
            <input id="pic" name="pic" size="50" value="" type="file">
            <?php if($articles['pic'] != ''): ?><img src="/springblog<?php echo ($articles["pic"]); ?>" height="30">
                <?php else: ?>
                暂无缩略图<?php endif; ?>
        </div>
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">内容</label>
            <div class="layui-input-block">
                <!-- 加载编辑器的容器 -->
                <script id="content" name="content" type="text/plain">
                    <?php echo ($articles["content"]); ?>
                </script>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">是否显示</label>
            <div class="layui-input-block">
                <input type="radio" name="is_show" value="1" title="是"  <?php if($articles["is_show"] == 1): ?>checked<?php else: endif; ?>>
                <input type="radio" name="is_show" value="0" title="否"  <?php if($articles["is_show"] == 0): ?>checked<?php else: endif; ?>>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn layui-btn-radius" lay-submit lay-filter="*">立即提交</button>
                <button type="reset" class="layui-btn layui-btn-primary layui-btn-radius">重置</button>
            </div>
        </div>
        <!-- 更多表单结构排版请移步文档左侧【页面元素-表单】一项阅览 -->
    </form>
</div>
<script src="/springblog/Public/layui/layui.js"></script>
<!-- 配置文件 -->
<script type="text/javascript" src="/springblog/ueditor/ueditor.config.js"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="/springblog/ueditor/ueditor.all.js"></script>
<script>
    layui.use('form', function () {
        var form = layui.form;
        //各种基于事件的操作，下面会有进一步介绍
    });

    //实例化编辑器
    //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
    UE.getEditor('content',{initialFrameWidth:1500,initialFrameHeight:400,});
//    <!-- 实例化编辑器 -->
//    var ue = UE.getEditor('container');
</script>

</body>
</html>