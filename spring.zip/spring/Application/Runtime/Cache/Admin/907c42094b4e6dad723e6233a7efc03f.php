<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>修改友链</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
       修改友链
    </div>
</div>
<div style="padding-top: 30px;">
    <form class="layui-form" action="/spring/Admin/Link/edit" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <input type="hidden" name="link_id" value="<?php echo ($data[link_id]); ?>">
        <div class="layui-form-item">
            <label class="layui-form-label">链接名称</label>
            <div class="layui-input-block">
                <input type="text" name="link_name" required  lay-verify="required" placeholder="接名称" autocomplete="off" class="layui-input" value="<?php echo ($data[link_name]); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">链接地址</label>
            <div class="layui-input-block">
                <input type="text" name="link_url" required  lay-verify="required" placeholder="链接地址" autocomplete="off" class="layui-input" value="<?php echo ($data[link_url]); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">排序</label>
            <div class="layui-input-block">
                <input type="text" name="sort"  lay-verify="required" placeholder="排序" autocomplete="off" class="layui-input" value="<?php echo ($data[sort]); ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">是否显示</label>
            <div class="layui-input-block">
                <input type="radio" name="link_visible" value="1"  title="是"  <?php if($data['link_visible'] == 1): ?>checked<?php endif; ?>>
                <input type="radio" name="link_visible" value="0" title="否"   <?php if($data['link_visible'] == 0): ?>checked<?php endif; ?>>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </div>
        <!-- 更多表单结构排版请移步文档左侧【页面元素-表单】一项阅览 -->
    </form>
</div>
<script src="/spring/Public/layui/layui.js"></script>
<script>
    layui.use('form', function(){
        var form = layui.form;
        //各种基于事件的操作，下面会有进一步介绍
        //监听提交
    });
</script>
</body>
</html>