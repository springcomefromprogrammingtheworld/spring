<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>文章分类列表</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "文章管理"."→"."文章分类列表";?>
    </div>
</div>
<div class="layui-field-box">
    <form class="layui-form" action="/spring/Admin/Article/sort" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
    <table class="layui-table" lay-size="lg">
        <thead>
        <tr>
            <th class="text-center">分类编号</th>
            <th class="text-center">排序</th>
            <th class="text-center">分类名</th>
            <th class="text-center">关键词</th>
            <th class="text-center">描述</th>
            <th class="text-center">操作</th>
        </tr>
        </thead>
        <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                <td class="text-center"><?php echo ($vo["cate_id"]); ?></td>
                <td class="text-center"><input class="layui-input" type="text" name="<?php echo ($vo["cate_id"]); ?>" value="<?php echo ($vo["sort"]); ?>"></td>
                <td><?php echo ($vo["cate_name"]); ?></td>
                <td class="text-center"><?php echo ($vo["keywords"]); ?></td>
                <td class="text-center"><?php echo ($vo["description"]); ?></td>
                <td class="text-center"><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Article/add/cate_id/<?php echo ($vo["cate_id"]); ?>">添加子分类</a><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Article/edit/cate_id/<?php echo ($vo["cate_id"]); ?>">修改</a><a class="layui-btn layui-btn-radius s-btn-danger" href="/spring/Admin/Article/del/cate_id/<?php echo ($vo["cate_id"]); ?>">删除</a></td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        <tr>
            <td></td>
            <td><input class="layui-btn layui-btn-radius s-btn-warm" type="submit" value="排序"></td>
        </tr>
    </table>
        </form>
</div>

<script src="/spring/Public/layui/layui.js"></script>
</body>
</html>