<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>权限菜单</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "权限管理"."→"."权限菜单";?>
    </div>
</div>
<div class="layui-field-box">
    <form class="layui-form" action="/spring/Admin/Admin/sort" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <table class="layui-table" lay-size="lg">
            <thead>
            <tr>
                <th class="text-center">权限ID</th>
                <th class="text-center">排序</th>
                <th class="text-center">权限名称</th>
                <th class="text-center">控制器/方法</th>
                <th class="text-center">权限级别</th>
                <th class="text-center">创建时间</th>
                <th class="text-center">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                    <td class="text-center"><?php echo ($vo["id"]); ?></td>
                    <td class="text-center"><input class="layui-input" type="text" name="<?php echo ($vo["id"]); ?>" value="<?php echo ($vo["sort"]); ?>"></td>
                    <td><?php echo str_repeat('―',$vo['level']*1); echo ($vo["title"]); ?></td>
                    <td class="text-center"><?php echo ($vo["name"]); ?></td>
                    <td class="text-center"><?php echo ($vo["level"]); ?>级</td>
                    <td class="text-center"><?php echo (date("Y-m-d H:i:s",$vo["create_time"])); ?></td>
                    <td class="text-center"><a href="javascript:;" onclick="auth_rule_edit(<?php echo ($vo["id"]); ?>)"
                                               class="layui-btn layui-btn-radius s-btn-warm">编辑</a><a
                            class="layui-btn layui-btn-radius s-btn-danger"
                            href="/spring/Admin/Admin/add_sub_rule/id/<?php echo ($vo["id"]); ?>">添加子权限</a></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
            <tr>
                <td></td>
                <td><input class="layui-btn layui-btn-radius s-btn-warm" type="submit" value="排序"></td>
            </tr>
        </table>
    </form>
    <div class="layui-form-item">
        <label class="layui-form-label"></label>
        <div class="page">
            <?php echo ($page); ?>
        </div>
    </div>
</div>
<div id="test1"></div>
<script>
    layui.use('layer', function () {
        var layer = layui.layer;
    });

    function auth_rule_edit(id) {
        layer.open({
            type: 2,
            area: ['500px', '400px'],
            title: '编辑权限',
            shadeClose: true,
            shade: 0.5,
            content: '<?php echo U("Admin/auth_rule_edit");?>?id=' + id,//这里content是一个URL，如果你不想让iframe出现滚动条，你还可以content: ['http://sentsin.com', 'no']
        });

    }
</script>
</body>
</html>