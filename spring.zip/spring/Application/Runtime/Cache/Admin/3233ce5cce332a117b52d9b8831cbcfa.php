<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>文章列表</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "文章管理"."→"."文章列表";?>
    </div>
</div>
<div class="layui-field-box">
    <form class="layui-form" action="/spring/Admin/Article/sort" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <table class="layui-table" lay-size="lg">
            <thead>
            <tr>
                <th class="text-center">文章ID</th>
                <th class="text-center">文章标题</th>
                <th class="text-center">缩略图</th>
                <th class="text-center">所属分类</th>
                <th class="text-center">显示</th>
                <th class="text-center">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                    <td class="text-center"><?php echo ($vo["id"]); ?></td>
                    <td class="text-center"><?php echo ($vo["title"]); ?></td>
                    <td class="text-center">
                        <?php if($vo['pic'] != ''): ?><img src="/spring/<?php echo ($vo["pic"]); ?>" >
                            <?php else: ?>
                            暂无缩略图<?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo ($vo["cate_name"]); ?></td>
                    <td class="text-center">
                        <?php if($vo['is_show'] == 1): ?>✔
                            <?php else: ?>
                            ✘<?php endif; ?>
                    </td>
                    <td class="text-center"><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Article/article_edit/id/<?php echo ($vo["id"]); ?>">修改</a><a class="layui-btn layui-btn-radius s-btn-danger" href="/spring/Admin/Article/del_article/id/<?php echo ($vo["id"]); ?>">删除</a></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <!-- 分页 -->
        <div class="page" style="width: 100%;height: 50px;">
            <?php echo ($page); ?>
        </div>
    </form>
</div>

<script src="/spring/Public/layui/layui.js"></script>
</body>
</html>