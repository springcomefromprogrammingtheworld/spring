<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>添加标签</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "标签管理"."→"."添加标签";?>
    </div>
</div>
<div style="padding-top: 30px;">
<form class="layui-form" action="/spring/Admin/Tag/add" method="post">
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">添加标签</label>
        <div class="layui-input-block">
            <textarea name="tag_name" placeholder="可以换行批量添加标签"  lay-verify="required" class="layui-textarea" style="width: 60%;"></textarea>
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-radius" lay-submit lay-filter="formDemo">立即提交</button>
            <button type="reset" class="layui-btn layui-btn-primary layui-btn-radius">重置</button>
        </div>
    </div>
</form>
</div>
<script src="/spring/Public/layui/layui.js"></script>
<script>
    //Demo
    layui.use('form', function(){
        var form = layui.form;
//        //监听提交
//        form.on('submit(formDemo)', function(data){
//            layer.msg(JSON.stringify(data.field));
//            return false;
//        });
    });
</script>

</body>
</html>