<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>添加管理员</title>
    <link type="text/css" rel="stylesheet" href="/springblog/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/springblog/Public/spring/spring.css"/>
</head>
<style>
    /*重写框架样式*/
    .layui-input-block{
        width: 50%;
    }
</style>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        编辑管理员
    </div>
</div>
<div style="padding-top: 30px;">
    <form class="layui-form" action="/springblog/Admin/Admin/admin_edit/id/2" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <div class="layui-form-item">
            <label class="layui-form-label">用户组</label>
            <div class="layui-input-block">
                <select name="group_id" lay-verify="required">
                    <option value="<?php echo ($res["group_id"]); ?>"><?php echo ($res["title"]); ?></option>
                    <option value="0">---请选择用户组---</option>
                    <?php if(is_array($group)): $i = 0; $__LIST__ = $group;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">账号</label>
            <div class="layui-input-block">
                <input value="<?php echo ($res["username"]); ?>" type="text" name="username" required  lay-verify="required" autocomplete="off" class="layui-input">
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">账号状态</label>
            <div class="layui-input-block">
                <?php if($_SESSION['aid'] == 1): ?><input type="radio" name="status" value="1" title="允许登录" <?php if($res["status"] == 1): ?>checked<?php endif; ?>>
                <input type="radio" name="status" value="0" title="禁用登录" <?php if($res["status"] == 0): ?>checked<?php endif; ?>>
                    <?php else: ?>
                    <p class="layui-form-label" style="text-align: center">
                        正常<input name="status" type="hidden" value="1"/>
                    </p><?php endif; ?>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-input-block">
                <input type="hidden" name="id" value="<?php echo ($res["id"]); ?>" />
                <button class="layui-btn layui-btn-radius" lay-submit lay-filter="formDemo">确认</button>
            </div>
        </div>
        <!-- 更多表单结构排版请移步文档左侧【页面元素-表单】一项阅览 -->
    </form>
</div>



<script src="/springblog/Public/layui/layui.js"></script>
<script>
    layui.use('form', function(){
        var form = layui.form;
        //各种基于事件的操作，下面会有进一步介绍
        //监听提交
    });
</script>
</body>
</html>