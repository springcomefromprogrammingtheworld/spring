<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>管理员列表</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "权限管理"."→"."管理员列表";?>
    </div>
</div>
<div class="layui-field-box">
        <table class="layui-table" lay-size="lg">
            <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">用户名</th>
                <th class="text-center">所属分组</th>
                <th class="text-center">最近登陆时间</th>
                <th class="text-center">登陆次数</th>
                <th class="text-center">登陆状态</th>
                <th class="text-center">创建时间</th>
                <th class="text-center">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr id="del<?php echo ($vo["id"]); ?>">
                    <td class="text-center"><?php echo ($vo["id"]); ?></td>
                  <td class="text-center"><?php echo ($vo["username"]); ?></td>
                    <td class="text-center"><?php echo ($vo["group"]); ?></td>
                  <td class="text-center"><?php if( !empty($vo['login_time']) ): echo (date("Y-m-d H:i:s",$vo["login_time"])); endif; ?></td>
                    <td class="text-center"><?php echo ($vo["login_count"]); ?></td>
                   <td class="text-center"><?php if( $vo["status"] == 1 ): ?>已允许<?php else: ?><span style="color:#F00">已禁用</span><?php endif; ?></td>
                  <td class="text-center"><?php echo (date("Y-m-d H:i:s",$vo["create_time"])); ?></td>
                    <td class="text-center"><?php if($vo['id'] != 1): ?><a class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Admin/admin_edit/id/<?php echo ($vo["id"]); ?>" >编辑</a>
                        <a class="layui-btn layui-btn-radius s-btn-danger" href="javascript:;" onclick="del(<?php echo ($vo[id]); ?>,'<?php echo ($vo["username"]); ?>')">删除</a><?php endif; ?></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    <!-- 分页 -->
    <div class="page" style="width: 100%;height: 50px;">
        <?php echo ($page); ?>
    </div>
</div>

<script>
    layui.use('layer', function () {
        var layer = layui.layer;
    });

    //删除管理员
    function del(id,name){
        $("#del"+id+" td").css('background','#CBDFF2');
        layer.confirm('你真的需要要删除非超级管理员'+name+'吗？',
                {icon: 3, title:'提示',btn: ['是的','取消'],shade: 0.5},
                function(index){
                    $.post("<?php echo U('Admin/admin_del');?>", { "id": id },function(data){
                        if(data == 1){
                            layer.msg('删除成功', { icon: 1, time: 1000 }, function(){
                                $("#del"+id).remove();
                            });
                        }else{
                            layer.msg('删除失败', {icon: 2, time: 2000 });
                        }
                    }, "json");
                },function(){
                    $("#del"+id+" td").css('border-top','0');
                    $("#del"+id+" td").css('border-bottom','1px solid #EFEFEF');
                }
        );
    }
</script>
</body>
</html>