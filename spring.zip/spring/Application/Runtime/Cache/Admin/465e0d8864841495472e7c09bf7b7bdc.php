<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>系统信息</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
</head>
<body>
    <div class="layui-field-box">
        <table class="layui-table" lay-size="lg">
            <?php if(is_array($info)): $i = 0; $__LIST__ = $info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                    <td class="text"><?php echo ($key); ?>：</td>
                    <td class="input"><?php echo ($v); ?></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    </div>
<script src="/spring/Public/layui/layui.js"></script>
</body>
</html>