<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>spring v1.0</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/layui/layui.js"></script>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>
    <script src="/spring/Public/js/base.js"></script>
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
    <!--头部导航 start-->
    <div class="layui-header">
        <div class="layui-logo">spring v1.0</div>
        <!-- 头部区域（可配合layui已有的水平导航） -->
        <ul class="layui-nav layui-layout-left">
            <li class="layui-nav-item"><a href="javascript:;">统计</a></li>
            <li class="layui-nav-item"><a href="/spring/Admin/Index/sys" name="iframe" target="iframe">系统信息</a></li>
            <li class="layui-nav-item"><a href="<?php echo U('Home/Index/index');?>" target="_blank">网站预览</a></li>
            <li class="layui-nav-item"><a href="/spring/Admin/Index/clear_cache/type/1" name="iframe" target="iframe">清除缓存</a></li>

        </ul>
        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item">
                <a href="javascript:;">
                    <?php if(is_array($admin_head)): $i = 0; $__LIST__ = $admin_head;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><img src='/spring/<?php echo ($vo["head"]); ?>' class="layui-nav-img"><?php endforeach; endif; else: echo "" ;endif; ?>
                    <?php echo ($adminname); ?>
                </a>
                <dl class="layui-nav-child">
                    <dd><a href="/spring/Admin/Index/edit_pwd" name="iframe" target="iframe">密码修改</a></dd>
                </dl>
            </li>
            <li class="layui-nav-item"><a href="<?php echo U('Login/logout');?>">退出</a></li>
        </ul>
    </div>
    <!--头部导航 end-->

    <!--左侧导航 start-->
    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
            <ul class="layui-nav layui-nav-tree" lay-filter="test">
                <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="layui-nav-item">
                        <a class="" href="javascript:;"><?php echo ($vo["title"]); ?></a>
                        <dl class="layui-nav-child">
                            <?php if(is_array($vo[sub])): $i = 0; $__LIST__ = $vo[sub];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?><dd><a href="/spring/Admin/<?php echo ($sub["name"]); ?>/ptitle/<?php echo ($vo["title"]); ?>/title/<?php echo ($sub["title"]); ?>" name="iframe" target="iframe"><?php echo ($sub["title"]); ?></a></dd><?php endforeach; endif; else: echo "" ;endif; ?>
                        </dl>
                    </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
    </div>
    <!--左侧导航 end-->


    <!--内容主体区域  start-->
    <div class="layui-body">
        <iframe frameborder="0" id="iframe" name="iframe" style="overflow: hidden"></iframe>
    </div>
    <!--内容主体区域  end-->


    <!-- 底部固定区域 start-->
    <div class="layui-footer">
        springblog.cn -spring
    </div>
    <!-- 底部固定区域 end-->

</div>

<style>
    /*重写框架样式*/
    .layui-nav-img {
        width: 50px;
        height: 50px;
        margin-right: 10px;
        border-radius: 50%;
    }
</style>
<script>
    //注意：选项卡 依赖 element 模块，否则无法进行功能性操作
    layui.use('element', function () {
        var element = layui.element;
    });
</script>
</body>
</html>