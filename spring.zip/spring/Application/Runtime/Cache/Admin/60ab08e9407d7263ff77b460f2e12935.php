<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>用户组</title>
    <link type="text/css" rel="stylesheet" href="/spring/Public/layui/css/layui.css"/>
    <link type="text/css" rel="stylesheet" href="/spring/Public/spring/spring.css"/>
    <script src="/spring/Public/js/jquery-3.2.1.min.js"></script>

</head>
<body>
<div class="layui-row" style="padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688">
    <div class="layui-col-xs6 layui-col-sm6 layui-col-md4" >
        <?php echo "权限管理"."→"."用户组";?>
    </div>
</div>
<div class="layui-field-box">
    <form class="layui-form" action="/spring/Admin/Link/sort" method="post"> <!-- 提示：如果你不想用form，你可以换成div等任何一个普通元素 -->
        <table class="layui-table" lay-size="lg">
            <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">角色/组</th>
                <th class="text-center">创建时间</th>
                <th class="text-center">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr id="del<?php echo ($vo["id"]); ?>">
                    <td class="text-center"><?php echo ($vo["id"]); ?></td>
                    <td class="text-center"><?php echo ($vo["title"]); ?></td>
                    <td class="text-center"><?php echo (date("Y-m-d H:i:s",$vo["create_time"])); ?></td>
                    <td class="text-center"><a  class="layui-btn layui-btn-radius s-btn-warm" href="/spring/Admin/Admin/group_edit//id/<?php echo ($vo["id"]); ?>">授权/编辑</a><a  class="layui-btn layui-btn-radius s-btn-danger" onclick="del(<?php echo ($vo["id"]); ?>)">删除</a></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    </form>
    <div class="layui-form-item">
        <label class="layui-form-label"></label>
        <div class="page">
            <?php echo ($page); ?>
        </div>
    </div>
</div>


<script src="/spring/Public/layui/layui.js"></script>
<script>
    layui.use('layer', function () {
        var layer = layui.layer;
    });

    //删除用户组
    function del(id){
            $("#del"+id+" td").css('background','#CBDFF2');
        layer.confirm('请确认该组下已经没有组成员了，否则需要重新授权，真的要删除吗？',
                {icon: 3, title:'提示',btn: ['是的','取消'],shade: 0.5},
                function(index){
                $.post("<?php echo U('Admin/group_del');?>", { "id": id },function(data){
                    if(data == 1){
                        layer.msg('删除成功', { icon: 1, time: 1000 }, function(){
                            $("#del"+id).remove();
                        });
                    }else{
                        layer.msg('删除失败', {icon: 2, time: 2000 });
                    }
                }, "json");
        },function(){
                $("#del"+id+" td").css('border-top','0');
                $("#del"+id+" td").css('border-bottom','1px solid #EFEFEF');
            }
        );
    }
</script>
</body>
</html>