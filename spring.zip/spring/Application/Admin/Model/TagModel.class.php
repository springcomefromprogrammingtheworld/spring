<?php
namespace Admin\Model;

use Think\Model;

class TagModel extends Model
{
    //自动验证
    protected $_validate = array(
        array('link_name', 'require', '必须填写链接名称'),
    );

    //标签列表
    public function lst()
    {
        $data = $this->select();
//        foreach ($data as $k => $v) {
//            $data[$k]['count']=M('Article_tag')->where(array('tid'=>$v['tid']))->count();
//        }
        return $data;
    }

    // 修改标签
    public function edit()
    {
        $tag_id = I('post.tag_id');
        $data['tag_name'] = I('post.tag_name');
        if (empty($data)) {
            $this->error = '标签名不能为空';
            return false;
        } else {
            return $this->where(array('tag_id' =>  $tag_id))->save($data);
        }
    }

    // 删除数据
    public function del(){
        $tag_id=I('get.tag_id',0,'intval');
        if($this->where(array('tag_id'=>$tag_id))->delete()){
            return true;
        }else{
            return false;
        }
    }

    // 添加标签
    public function add_link()
    {
        $str = I('post.tag_name');
        if (empty($str)) {
            $this->error = '标签名不能为空';
            return false;
        } else {
            $str = nl2br(trim($str));
            $tnames = explode("<br />", $str);
            foreach ($tnames as $k => $v) {
                $v = trim($v);
                if (!empty($v)) {
                    $data['tag_name'] = $v;
                    $this->add($data);
                }
            }
            return true;
        }
    }

    // 根据tag_id获取单条数据
    public function get_tag($tag_id)
    {
        return $this->where(array('tag_id' => $tag_id))->find();
    }
}