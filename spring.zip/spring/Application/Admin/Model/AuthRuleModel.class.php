<?php
namespace Admin\Model;

use Think\Model;

class AuthRuleModel extends Model
{
    //自动验证
    protected $_validate = array(
        array('name','','不可添加重复权限',0,'unique',1),
    );
    //无限级分类树
    public function tree($data, $pid = 0)
    {
        static $treeArr = array();
        foreach ($data as $v) {
            if ($v['pid'] == $pid) {
                $treeArr[] = $v;
                $this->tree($data, $v['id']);
            }
        }
        return $treeArr;
    }

    //传递分类数据data和分类一个cate_id 找出下面所有子分类包括自身
    public function getSubIds($data, $id)
    {
        $list = $this->tree($data, $id);
        return $list;
    }

    //权限及菜单
    public function auth_rule()
    {
        $nowPage = isset($_GET['p'])?$_GET['p']:1;
        $list = $this->where('status=1')->page($nowPage.',5')->select();
        $count = $this->where('status=1')->count();// 查询满足要求的总记录数
        $Page = new \Think\Page($count,5);// 实例化分页类 传入总记录数和每页显示的记录数
        $Page->lastSuffix = false;
        $Page -> setConfig('theme','%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
        $Page->setConfig('first','首页');
        $Page->setConfig('last','尾页');
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();// 分页显示输出
        $data['list'] = $list;
        $data['show'] = $show;
        return $data;
    }


    //添加权限菜单
    public function add_rule(){
        $data = $this->select();
        $treeArr = $this->tree($data);
        return $treeArr;
    }


    //添加用户组
    public function group_add()
    {
        $data = $this->select();
        $treeArr = $this->tree($data);
        $data = $this->genTree($treeArr);
        return $data;
    }



    //将所有子分类数组组装到所属父类数组下
    function genTree($items, $id = 'id', $pid = 'pid', $son = 'children')
    {
        $tree = array(); //格式化的树
        $tmpMap = array();  //临时扁平数据

        foreach ($items as $item) {
            $tmpMap[$item[$id]] = $item; //设置临时数组键值为当前项id值，用id来索引
        }

        foreach ($items as $item) {
            if (isset($tmpMap[$item[$pid]])) {  //临时数组键值是否设置，不设置为false，过滤父类(当前项下标从零开始)
                $tmpMap[$item[$pid]][$son][] = &$tmpMap[$item[$id]];
            } else {
                $tree[] = &$tmpMap[$item[$id]];//设置顶级
            }
        }
        return $tree;
    }


    //添加子权限
    public function add_sub_rule()
    {
        $data = I('post.');
        if ($data['pid'] == 0) {
            $data['level'] = 1;
        } else {
            $where['id'] = array('eq', $data['pid']);
            $res = $this->where($where)->select();
            $data['level'] = $res[0]['level'] + 1;
        }
        $data['create_time'] = time();
        if ($this->create($data)) {
            if($this->add()){
                return true;
            }else{
                return false;
            }
        }
    }

    //获取单条权限
    public function get_rule()
    {
        $id = I('id');
        return $this->where(array('id' => $id))->find();
    }

    //权限菜单排序
    public function sort(){
        $data = I('post.');
        if (!empty($data)) {
            foreach ($data as $k => $v) {
                $this->where(array('id' => $k))->save(array('sort' => $v));
            }
            return true;
        }else{
            return false;
        }
    }

}