<?php
namespace Admin\Model;

use Think\Model;

class ArticleCategoryModel extends Model
{
    //自动验证
    protected $_validate = array(
        array('cate_name', 'require', '分类名不能为空'),
        array('sort', 'number', '排序必须为数字'),
    );

    //添加文章分类
    public function add_cate()
    {
        $data = I('post.');
        if ($this->create($data)) {
            return $this->add();
        }
    }

    /**
     * 获取所有文章分类
     * @param int $cate_id 文章分类id
     * @return mixed
     */
    public function get_AllCate($cate_id = null)
    {
        if ($cate_id) {
            $res = $this->order('sort desc')->select();
            $data = $this->tree($res); //查询所有文章分类
            $res = $this->level($data, '',$cate_id);//文章分类等级处理
            return $res;
        } else {
            $res = $this->order('sort desc')->select();
            $data = $this->tree($res); //查询所有文章分类
            $res = $this->level($data);//文章分类等级处理
            return $res;
        }
    }

    //无限级分类树
    public function tree($data, $pid = 0, $level = 1)
    {
        static $treeArr = array();
        foreach ($data as $v) {
            if ($v['pid'] == $pid) {
                $v['level'] = $level;
                $treeArr[] = $v;
                $this->tree($data, $v['cate_id'], $level + 1);
            }
        }
        return $treeArr;
    }

    //传递分类数据data和分类一个cate_id 找出下面所有子分类包括自身
    public function getSubIds($data, $id)
    {
        $list = $this->tree($data, $id);
        return $list;
    }

    //文章分类等级区分处理
    public function level($data, $pid = 0, $select_id = '')
    {
        for ($i = 0; $i < count($data); $i++) {
            for ($j = 0; $j < $data[$i]['level']; $j++) {
                $level .= '-&nbsp;&nbsp;';
            }
            if ($select_id == $data[$i][cate_id]) {
                $str .= "<option selected='selected' value=" . $data[$i][cate_id] . ">" . $level . $data[$i][cate_name] . "<option>";
            } else {
                $str .= "<option ' value=" . $data[$i][cate_id] . ">" . $level . $data[$i][cate_name] . "<option>";
            }
            $level = '';
        }
        return $str;
    }

    //文章分类列表模板
    public function cate_list($data)
    {
        for ($i = 0; $i < count($data); $i++) {
            for ($j = 0; $j < $data[$i]['level']; $j++) {
                $data[$i][cate_name] = '-&nbsp;' . $data[$i][cate_name];
            }
        }
        return $data;
    }

    // 根据cate_id获取单条文章分类数据
    public function get_cate($cate_id)
    {
        return $this->where(array('cate_id' => $cate_id))->find();
    }


    // 修改文章分类
    public function edit()
    {
        $data = I('post.');
        if (empty($data)) {
            $this->error = '修改分类数据不能为空';
            return false;
        } else {
            return $this->where(array('cate_id' =>  $data['cate_id']))->save($data);
        }
    }

    //删除文章分类
    public function del(){
        $cate_id=I('cate_id');
        $data=$this->select();
        $child=$this->getSubIds($data,$cate_id);
        if(!empty($child)){
            $this->error = '请先删除子分类';
            return false;
        }
        if($this->where(array('cate_id'=>$cate_id))->delete()){
            return true;
        }else{
            return false;
        }
    }

    //文章分类排序
    public function sort(){
        $data = I('post.');
        if (!empty($data)) {
            foreach ($data as $k => $v) {
                $this->where(array('cate_id' => $k))->save(array('sort' => $v));
            }
            return true;
        }else{
            return false;
        }
    }

    //文章分类列表
    public function cate_lst(){
        $res = $this->order('sort desc')->select();
        $data = $this->tree($res); //查询所有文章分类
        $cate_list = $this->cate_list($data);//文章分类列表模板
        return $cate_list;
    }


}