<?php
namespace Admin\Model;

use Think\Model;

class LinksModel extends Model
{
    //自动验证
    protected $_validate = array(
        array('link_name', 'require', '必须填写链接名称'),
        array('link_url', 'require', '必须填写链接地址'),
        array('sort', 'number', '排序必须为数字'),
        array('sort', 'require', '排序必填'),
    );

    // 添加友链
    public function add_link()
    {
        $data = I('post.');
        if (!$this->create($data)) {
            return false;//数据创建失败
        } else {
            $data['link_url'] = 'http://' . str_replace(array('http://', 'https://'), '', $data['link_url']);
            $link_id = $this->add($data);
            return $link_id;
        }
    }

    // 修改友链
    public function edit()
    {
        $data = I('post.');
        if (empty($data)) {
            return false;
        } else {
            $data['link_url'] = 'http://' . str_replace(array('http://', 'https://'), '', $data['link_url']);
            return $this->where(array('link_id' => $data['link_id']))->save($data);
        }
    }


    // 传递link_del和link_visible获取对应数据(友链列表)
    public function lst($link_del = 0, $link_visible = 1)
    {
        $where = array(
            'link_del' => $link_del,
            'link_visible' => $link_visible,
        );
        // 如果是获取全部链接；则删除link_visible限制
        if ($link_visible === 'all') {
            unset($where['link_visible']);
        }
        return $this->where($where)->order('sort')->select();
    }

    // 传递link_id获取单条数据
    public function get_link($link_id)
    {
        return $this->where(array('link_id' => $link_id))->find();
    }

    //友情链接排序
    public function sort(){
        $data = I('post.');
        if (!empty($data)) {
            foreach ($data as $k => $v) {
                $this->where(array('link_id' => $k))->save(array('sort' => $v));
            }
            return true;
        }else{
            return false;
        }
    }

    //删除友情链接
    public function del(){
        $link_id=I('get.link_id',0,'intval');
        if($this->where(array('link_id'=>$link_id))->delete()){
            return true;
        }else{
            return false;
        }
    }

}