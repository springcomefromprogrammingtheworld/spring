<?php
namespace Admin\Model;
use Think\Model\ViewModel;;
class ArticleViewModel extends ViewModel {

    public $viewFields = array(

        'Article'=>array('id','title','pic','is_show','_type'=>'LEFT'),
        'ArticleCategory'=>array('cate_name','_on'=>'Article.cate_id=ArticleCategory.cate_id'),

    );


}