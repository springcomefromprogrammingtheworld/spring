<?php
return array(
    //'配置项'=>'配置值'
    'DEFAULT_CONTROLLER'  => 'Login',       //后台默认访问的控制器
    'DEFAULT_ACTION'  	  => 'login',        //后台默认访问的方法
);