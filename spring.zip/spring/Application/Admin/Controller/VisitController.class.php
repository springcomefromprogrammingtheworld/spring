<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Auth;
use Common\Controller\AuthController;
//访客控制器
class VisitController extends  AuthController
{
    /*访客列表*/
    public function lst(){
        $this->display();
    }
}