<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Auth;
use Common\Controller\AuthController;
//权限控制类
class IndexController extends  AuthController
{
    /*后台首页*/
    public function index(){
        $m = M('auth_rule');
        $field = 'id,name,title,sort';
        $where['pid'] = 0;		//顶级ID
        $where['is_show'] = 1;	//显示状态
        $data = $m->field($field)->where($where)->order('sort ASC')->select();//查询顶级菜单
        $auth = new Auth();
        //没有权限的顶级菜单不显示
        foreach ($data as $k=>$v){
            if(!$auth->check($v['name'], session('aid')) && session('aid') != 1){
                unset($data[$k]);
            }else{
                // is_show = 1    为菜单显示状态
                $data[$k]['sub'] = $m->field($field)->where('pid='.$v['id'].' AND is_show=1')->order('id ASC')->select();
                foreach ($data[$k]['sub'] as $k2 => $v2){
                    if(!$auth->check($v2['name'], session('aid')) && session('aid') != 1){
                        unset($data[$k]['sub'][$k2]);
                    }
                }
            }
        }
        $this->assign('data',$data);	// 顶级
        $this->display();
    }

    //修改密码
    public function edit_pwd(){
        if(!empty($_POST)){
            $m = M('admin');
            $where['id'] = session('aid');
            $where['password'] = md5(I('old_pwd'));
            $new_pwd = md5(I('new_pwd'));
            $data = $m->field('id')->where($where)->find();
            if(empty($data)){
                $this->error("失败，原密码错误");	//失败，原密码错误
            }else{
                $result = $m->where('id='.$where['id'])->data('password='.$new_pwd)->save();
                if($result){
                    session('aid',null);
                    session('username',null);
                    $this->show("<div class='layui-row' style='padding-left: 20px;font-size: 24px;padding-top: 20px;border-bottom: 2px solid #009688'>修改密码成功,请刷新页面重新登录!!!!!</div>");	//修改成功
                }else{
                    $this->success("修改密码失败");	//修改失败
                }
            }
        }else{
            $this->display();
        }
    }
    //循环删除目录和文件函数
    public function delDirAndFile($dirName){
        if ( $handle = opendir( "$dirName" ) ) {
            while ( false !== ( $item = readdir( $handle ) ) ) {
                if ( $item != "." && $item != ".." ) {
                    if ( is_dir( "$dirName/$item" ) ) {
                        delDirAndFile( "$dirName/$item" );
                    } else {
                        unlink( "$dirName/$item" );
                    }
                }
            }
            closedir( $handle );
            if( rmdir( $dirName ) ) return true;
        }
    }


    //清除缓存
    public function clear_cache(){
        $str = I('clear');	//防止搜索到第一个位置为0的情况
        $type=I('type');
        if($str){
            //strpos 参数必须加引号
            //删除Runtime/Cache/admin目录下面的编译文件
            if(strpos("'".$str."'", '1')){
                $dir = APP_PATH.'Runtime/Cache/Admin/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Cache/Home目录下面的编译文件
            if(strpos("'".$str."'", '2')){
                $dir = APP_PATH.'Runtime/Cache/Home/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Data/目录下面的编译文件
            if(strpos("'".$str."'", '3')){
                $dir = APP_PATH.'Runtime/Data/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Temp/目录下面的编译文件
            if(strpos("'".$str."'", '4')){
                $dir = APP_PATH.'Runtime/Temp/';
                $this->delDirAndFile($dir);
            }
            $this->ajaxReturn(1);	//成功
        }else if($type){
            $this->display();
        }else{
            $this->ajaxReturn(2);	//失败
        }

    }


    //服务器系统信息
    public function sys(){
        $info = array(
            '操作系统'=>PHP_OS,
            '运行环境'=>$_SERVER["SERVER_SOFTWARE"],
            'PHP运行方式'=>php_sapi_name(),
            'ThinkPHP版本'=>THINK_VERSION.' [ <a href="http://thinkphp.cn" target="_blank">查看最新版本</a> ]',
            '上传附件限制'=>ini_get('upload_max_filesize'),
            '执行时间限制'=>ini_get('max_execution_time').'秒',
            '服务器时间'=>date("Y年n月j日 H:i:s"),
            '北京时间'=>gmdate("Y年n月j日 H:i:s",time()+8*3600),
            '服务器域名/IP'=>$_SERVER['SERVER_NAME'].' [ '.gethostbyname($_SERVER['SERVER_NAME']).' ]',
            '剩余空间'=>round((disk_free_space(".")/(1024*1024)),2).'M',
            'register_globals'=>get_cfg_var("register_globals")=="1" ? "ON" : "OFF",
            'magic_quotes_gpc'=>(1===get_magic_quotes_gpc())?'YES':'NO',
            'magic_quotes_runtime'=>(1===get_magic_quotes_runtime())?'YES':'NO',
        );
        $this->assign('info',$info);
        $this->display();
    }

}