<?php
namespace Admin\Controller;

use Think\Controller;
use Think\Auth;
use Common\Controller\AuthController;
//友情链接控制器
class LinkController extends AuthController
{
    // 定义数据
    private $db;
    public function __construct()
    {
        parent::__construct();
        $this->db = D('Links');
    }

    // 友情链接列表
    public function lst()
    {
        $data = $this->db->lst(0, 'all');
        $this->assign('data', $data);
        $this->display();
    }

    // 添加友情链接
    public function add()
    {
        if (IS_POST) {
            if ($this->db->add_link()) {
                $this->success('友情链接添加成功', U('Admin/Link/lst'));
            } else {
                $this->error($this->db->getError());//得到错误信息
            }
        } else {
            $this->display();
        }
    }

    // 修改友情链接
    public function edit()
    {
        if (IS_POST) {
            if ($this->db->edit()) {
                $this->success('友情链接修改成功', U('Admin/Link/lst'));
            } else {
                $this->error("友情链接修改失败");
            }
        } else {
            $link_id = I('link_id');
            $data = $this->db->get_link($link_id);
            $this->assign('data', $data);
            $this->display();
        }
    }

    // 删除标签
    public function del(){
        if($this->db->del()){
            $this->success('删除成功');
        }else{
            $this->error('删除失败');
        }
    }

    //排序
    public function sort()
    {
        if (IS_POST) {
            if ($this->db->sort()) {
                $this->success('排序成功', U('Admin/Link/lst'));
            } else {
                $this->error("排序失败");
            }
        }
    }
}