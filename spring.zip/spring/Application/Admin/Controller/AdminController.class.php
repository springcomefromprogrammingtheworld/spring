<?php
namespace Admin\Controller;
use Think\Auth;
use Common\Controller\AuthController;


//管理控制器
class AdminController extends AuthController
{
    // 定义数据表
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = D('AuthRule');
    }

    //管理员列表
    public function admin_lst()
    {
        $m = M('Admin');
        $count = $m->where('is_show=1')->count();// 查询满足要求的总记录数
        $Page = new \Think\Page($count, 5);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $m->where('is_show=1')->order('id asc')->limit($Page->firstRow . ',' . $Page->listRows)->select();

        $Page->lastSuffix = false;
        $Page->setConfig('theme', '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '尾页');
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $show = $Page->show();// 分页显示输出


        //获取用户所属分组 start
        $auth = new Auth();
        foreach ($list as $k => $v) {
            $group = $auth->getGroups($v['id']);//根据用户id获取用户组,返回值为数组
            $list[$k]['group'] = $group[0]['title'];//分组标题
        }
        //获取用户所属分组 end

        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->display();
    }

    //添加管理员
    public function admin_add()
    {
        if (!empty($_POST)) {
            $m = M('admin');
            $data['username'] = I('username');
            $data['password'] = md5(I('password'));
            $data['create_time'] = time();        //创建时间
            $data['head'] =I('head');
            $where['username'] = I('username');
            $result = $m->where($where)->find();
            if (!empty($result)) {
                $this->error('用户名重复!');
            }
            if ($_FILES['head']['tmp_name'] != '') {
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 3145728;// 设置附件上传大小
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->savePath = './ueditor/upload/'; // 设置附件上传目录
                $upload->rootPath = './'; // 设置附件上传目录
                $info = $upload->uploadOne($_FILES['head']);
                if (!$info) {
                    $this->error($upload->getError());
                } else {
                    $data['head'] = $info['savepath'] . $info['savename'];
                }
            }
            //添加用户
            $result['uid'] = $m->add($data);
            $result['group_id'] = I('group_id');    //用户组ID
            if ($result['uid']) {
                $m = M('auth_group_access');
                //分配用户组
                if ($m->add($result)) {
                    $this->success("分配用户组成功");    //分配用户组成功
                } else {
                    $this->error("分配用户组失败");    //分配用户组失败
                }
            } else {
                $this->error("添加用户失败");  //添加用户失败
            }
        } else {
            $m = M('auth_group');
            $data = $m->field('id,title')->select();
            $this->assign('data', $data);
            $this->display();
        }
    }

    //编辑管理员
    public function admin_edit()
    {
        if (!empty($_POST)) {
            //修改所属组
            $access = M('auth_group_access');
            if (empty($_POST['group_id'])) {
                $this->error('请选择用户组');
            }
            $result = $access->where('uid=' . $_POST['id'])->find();
            if (empty($result)) {
                $map['uid'] = $_POST['id'];
                $map['group_id'] = $_POST['group_id'];
                $access->add($map);
            } else {
                $save['group_id'] = $_POST['group_id'];
                $access->where('uid=' . $_POST['id'])->save($save);
            }
            $data['id'] = $_POST['id'];
            if (!empty($_POST['password'])) {
                $data['password'] = md5($_POST['password']);
            }
            if ($_POST['status'] >= 0) {
                $data['status'] = $_POST['status'];
            }
            $m = M('admin');
            $result = $m->where('id=' . $data['id'])->save($data);
            if ($result === false) {
                $this->error('修改失败');
            } else {
                $this->success('修改成功',U('Admin/admin_lst'));
            }
        } else {
            $m = M('admin');
            $result = $m->where('id=' . I('id'))->find();

            //获取当前所属组 start
            $auth = new Auth();
            $group = $auth->getGroups($result['id']);
            $result['title'] = $group[0]['title'];
            $result['group_id'] = $group[0]['group_id'];
            $this->assign('res', $result);
            //获取当前所属组 end

            //获取所有组 start
            $m = M('auth_group');
            $group = $m->order('id DESC')->select();
            $this->assign('group', $group);
            //获取所有组 end
            $this->display();
        }
    }

    //删除非超级管理员
    public function admin_del(){
        $id = $_POST['id'];		//用户ID
        if($id == 1){
            $this->ajaxReturn(0);	//不允许删除超级管理员
        }
        $m = M('auth_group_access');
        $m->where('uid='.$id)->delete();   //删除权限表里面给的权限

        $admin = M('admin');
        $result = $admin->where('id='.$id)->delete();
        if ($result){
            $this->ajaxReturn(1);	//成功
        }else {
            $this->ajaxReturn(0);	//删除失败
        }
    }

    //用户组
    public function auth_group()
    {
        $m = M('auth_group');
        $count = $m->where('status=1')->count();// 查询满足要求的总记录数
        $Page = new \Think\Page($count, 5);// 实例化分页类 传入总记录数和每页显示的记录数(25)
        $Page->lastSuffix = false;
        $Page->setConfig('theme', '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '尾页');
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $show = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $m->where('status=1')->order('id asc')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->display();
    }

    //编辑用户组
    public function group_edit()
    {
        $m = M('auth_group');
        if (!empty($_POST)) {
            $data['id'] = I('id');
            $data['title'] = I('title');
            $data['rules'] = implode(',', I('rules'));//组成字符串
            $where['id'] =$data['id'];
            if ($m->where($where)->save($data)) {
                $this->success('修改成功');
            } else {
                $this->error('数据没有修改');
            }
        } else {
            //获取用户组权限 start
            $where['id'] = I('id');    //组ID
            $reuslt = $m->field('id,title,rules')->where($where)->find();
            $reuslt['rules'] = ',' . $reuslt['rules'] . ',';
            $this->assign('reuslt', $reuslt);
            //获取用户组权限 end

            //获取所有权限菜单 start
            $data = $this->db->group_add();
            $this->assign('data', $data);
            //获取所有权限菜单 end
            $this->display();
        }
    }

    //添加用户组
    public function group_add()
    {
        static $array = array();
        if (!empty($_POST)) {
            $data['rules'] = I('rules');
            if (empty($data['rules'])) {
                $this->error('(角色/组)权限不能为空');
            }
            $m = M('auth_group');
            $data['title'] = I('title');
            $data['rules'] = implode(',', $data['rules']);
            $data['create_time'] = time();
            if ($m->add($data)) {
                $this->success('角色/用户组添加成功', U('Admin/auth_group'));
            } else {
                $this->error('添加失败');
            }
        } else {
            $data = $this->db->group_add();
            $this->assign('data', $data);
            $this->display();
        }
    }

    //删除组
    public function group_del()
    {
        $where['id'] = I('id');
        $m = M('auth_group');
        if ($m->where($where)->delete()) {
            $this->ajaxReturn(1);
        } else {
            $this->ajaxReturn(0);
        }
    }

    //权限及菜单
    public function auth_rule()
    {
        $data = $this->db->auth_rule();
        $this->assign('list', $data['list']);// 赋值数据集
        $this->assign('page', $data['show']);// 赋值分页输出
        $this->display();
    }

    //添加权限菜单
    public function add_rule()
    {
        if (!empty($_POST)) {
            //添加权限菜单 satrt
            $m = M('auth_rule');
            $data['name'] = I('name');
            if (empty($data['name'])) {
                $data['name'] = null;
            }
            $data['title'] = I('title');
            $data['pid'] = I('pid');
            if ($data['pid'] == 0) {
                $data['level'] = 1;
            } else {
                $where['id'] = array('eq', $data['pid']);
                $res = $m->where($where)->select();
                $data['level'] = $res[0]['level'] + 1;
            }
            $data['remark'] = I('remark');
            $data['create_time'] = time();
            if ($m->add($data)) {
                $this->success('添加权限菜单成功');    //成功
            } else {
                $this->error('添加权限菜单失败');    //失败
            }
            //添加权限菜单 end
        } else {
            $data = $this->db->add_rule();
            $this->assign('data', $data);
            $this->display();

        }
    }

    //添加子权限菜单
    public function add_sub_rule()
    {
        if (!empty($_POST)) {
            if ($this->db->add_sub_rule()) {
                $this->success('添加子权限菜单成功');    //成功
            } else {
                $this->error('不可添加重复权限');    //失败
            }
        } else {
            $data = $this->db->get_rule();
            $this->assign('data', $data);
            $this->display();
        }
    }
    //编辑权限组
    public function auth_rule_edit()
    {
        if (!empty($_POST)) {
            $m = M('auth_rule');
            $_POST['update_time'] = time();
            $result = $m->save($_POST);
            if ($result) {
                $this->success('修改成功');
            } else {
                $this->error('修改失败');
            }
        } else {
            $m = M('auth_rule');
            $where['id'] = $_GET['id'];
            $result = $m->where($where)->find();
            $result['create_time'] = date('Y-m-d H:i:s', $result['create_time']);
            $this->assign('result', $result);
            $this->display();
        }
    }
    //权限菜单排序
    public function sort()
    {
        if (IS_POST) {
            if ($this->db->sort()) {
                $this->success('排序成功', U('Admin/Admin/auth_rule'));
            } else {
                $this->error("排序失败");
            }
        }
    }
}