<?php
namespace Admin\Controller;
use Think\Controller;
//不验证的控制器
class LoginController extends Controller
{
    /*后台管理人员登陆*/
    public function login()
    {
        if (!empty($_POST)) {
            $map['username'] = I('username');   //用户名
            $map['password'] = md5(I('password'));//密码
            $map['code']=I('code');
            $m = M('admin');
            //检验验证码
            $code_res=$this->check_verify($map['code']);
            //检验账户密码
            $result = $m->field('id,username,login_count,status')->where($map)->find();
            if ($result&&$code_res) {
                if ($result['status'] == 0) {
                    $this->error('登录失败，账号被禁用', U('Login/login'));
                }
                session('aid', $result['id']);    //管理员ID
                session('username', $result['username']);    //管理员名称
                //保存登录信息到数据库
                $data['id'] = $result['id'];    //用户ID
                $data['login_ip'] = ip2long(get_client_ip()) ;  //最后登录IP
                $data['login_time'] = time();        //最后登录时间
                $data['login_count'] = $result['login_count'] + 1;
                $m->save($data);
                $this->success('验证成功，正在跳转到后台', U('Index/index'));
            } else {
                $this->error('账户密码or验证码错误', U('Login/login'));
            }
        } else {
            if (session('aid')) {
                $this->error('已登录，正在跳转到后台', U('Index/index'));
            }
            $this->display();
        }
    }
    /*验证码*/
    public function verify(){
        ob_clean();		//清除缓存
        $Verify = new \Think\Verify();
        $Verify->fontSize = 30;	//验证码字体大小
        $Verify->length = 4;	//验证码位数
        $Verify->entry();
    }

    // 检测输入的验证码是否正确，$code为用户输入的验证码字符串
    function check_verify($code, $id = ''){
        $verify = new \Think\Verify();
        return $verify->check($code, $id);
    }


    /* 退出登录 */
    public function logout(){
        session('aid',null);	//注销 uid ，username
        session('username',null);
        $this->success('退出登录成功',U('Login/login'));
    }


    //没有权限执行动画
    public function no_control(){
        $this->display();
    }
}