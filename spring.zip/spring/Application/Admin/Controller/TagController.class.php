<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Auth;
use Common\Controller\AuthController;
//标签控制器
class TagController extends  AuthController
{
    // 定义数据
    private $db;
    public function __construct()
    {
        parent::__construct();
        $this->db = D('Tag');
    }
    //标签列表
    public function lst(){
        $data=$this->db->lst();
        $this->assign('data',$data);
        $this->display();
    }

    // 添加标签
    public function add(){
        if(IS_POST){
            if($this->db->add_link()){
                $this->success('标签添加成功',U('Admin/Tag/lst'));
            }else{
                $this->error('标签添加失败');
            }
        }else{
            $this->display();
        }
    }

    // 修改标签
    public function edit(){
        if(IS_POST){
            if($this->db->edit()){
                $this->success('修改成功', U('Admin/Tag/lst'));
            }else{
                $this->error("修改失败");
            }
        }else{
            $tag_id=I('tag_id');
            $data=$this->db->get_tag($tag_id);
            $this->assign('data',$data);
            $this->display();
        }
    }

    // 删除标签
    public function del(){
        if($this->db->del()){
            $this->success('删除成功');
        }else{
            $this->error('删除失败');
        }
    }
}