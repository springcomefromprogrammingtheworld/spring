<?php
namespace Admin\Controller;

use Think\Controller;
use Think\Auth;
use Common\Controller\AuthController;

//文章控制器
class ArticleController extends AuthController
{
    // 定义数据表
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = D('ArticleCategory');
    }

    //文章列表
    public function lst()
    {
        $article=D('ArticleView');
        $count=$article->count();// 查询满足要求的总记录数
        $Page= new \Think\Page($count,5);
        $Page->lastSuffix = false;
        $Page->setConfig('theme', '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '尾页');
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $show=$Page->show();
        $list =$article->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }

    //添加文章分类
    public function add()
    {
        if (IS_POST) {
            if ($this->db->add_cate()) {
                $this->success('分类添加成功', U('Admin/Article/cate_lst'));
            } else {
                $this->error($this->db->getError());
            }
        } else {
            $cate_id = I('get.cate_id', 0, 'intval');
            $data = $this->db->get_AllCate($cate_id);
            $this->assign("data", $data);
            $this->display();
        }
    }

    //发布新文章
    public function publish()
    {
        $article = D('article');
        if (IS_POST) {
            $data['title'] = I('title');
            $data['content'] = htmlspecialchars_decode(I('content'));
            $data['description'] = I('description');
            $data['author'] = I('author');
            $data['key'] = I('key');
            $data['is_show'] = I('is_show');
            $data['cate_id'] = I('cate_id');
            $data['time'] = time();
            if ($_FILES['pic']['tmp_name'] != '') {
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 3145728;// 设置附件上传大小
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->savePath = './ueditor/upload/'; // 设置附件上传目录
                $upload->rootPath = './'; // 设置附件上传目录
                $info = $upload->uploadOne($_FILES['pic']);
                if (!$info) {
                    $this->error($upload->getError());
                } else {
                    $data['pic'] = $info['savepath'] . $info['savename'];
                }
            }
            if ($article->create($data)) {
                if ($article->add()) {
                    $this->success('添加文章成功！', U('lst'));
                } else {
                    $this->error('添加文章失败！');
                }
            } else {
                $this->error($article->getError());
            }

            return;
        }
        $Article = D('ArticleCategory');
        $cateres = $Article->select();
        $cateres = $Article->tree($cateres);
        $data = $Article->level($cateres);
        $this->assign('data', $data);
        $this->display();
    }



    //文章分类列表
    public function cate_lst()
    {
        $data = $this->db->cate_lst();
        $this->assign("data", $data);
        $this->display();
    }

    //修改文章分类
    public function edit()
    {
        if (IS_POST) {
            if ($this->db->edit()) {
                $this->success('修改文章分类成功', U('Admin/Article/cate_lst'));
            } else {
                $this->error("修改文章分类失败");
            }
        } else {
            $cate_id = I('cate_id');
            $data = $this->db->get_cate($cate_id);
            $this->assign('data', $data);
            $this->display();
        }
    }

    //删除文章分类
    public function del()
    {
        if ($this->db->del()) {
            $this->success('删除文章分类成功', U('Admin/Article/cate_lst'));
        } else {
            $this->error("请先删除子分类");
        }
    }

    //文章分类排序
    public function sort()
    {
        if (IS_POST) {
            if ($this->db->sort()) {
                $this->success('排序成功', U('Admin/Article/cate_lst'));
            } else {
                $this->error("排序失败");
            }
        }
    }

    //修改文章
    public function article_edit(){
        $article=D('article');
        if(IS_POST){
            $data['title'] = I('title');
            $data['content'] = htmlspecialchars_decode(I('content'));
            $data['description'] = I('description');
            $data['author'] = I('author');
            $data['key'] = I('key');
            $data['is_show'] = I('is_show');
            $data['cate_id'] = I('cate_id');
            $data['id']=I('id');
            if($_FILES['pic']['tmp_name']!=''){
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize   =     3145728 ;// 设置附件上传大小
                $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->savePath  =      './ueditor/upload/'; // 设置附件上传目录
                $upload->rootPath  =      './'; // 设置附件上传目录
                $info   =   $upload->uploadOne($_FILES['pic']);
                if(!$info){
                    $this->error($upload->getError());
                }else{
                    $data['pic']=$info['savepath'].$info['savename'];
                }
            }
            if($article->create($data)){
                $save=$article->save();
                if($save !== false){
                    $this->success('修改文章成功！',U('lst'));
                }else{
                    $this->error('修改文章失败！');
                }
            }else{
                $this->error($article->getError());
            }

            return;
        }
        $articles=$article->find(I('id'));
        $articles['content']=htmlspecialchars_decode($articles['content']);//html处理
        $this->assign('articles',$articles);

        $Article = D('ArticleCategory');
        $cateres = $Article->select();
        $data = $Article->tree($cateres);
        $this->assign('data', $data);
        $this->display();
    }
   //删除文章
    public function del_article(){
        $article=D('article');
        if($article->delete(I('id'))){
            $this->success('删除文章成功！',U('lst'));
        }else{
            $this->error('删除文章失败！');
        }
    }
}